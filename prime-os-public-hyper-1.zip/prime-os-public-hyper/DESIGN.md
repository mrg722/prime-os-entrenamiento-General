# PRIME OS DESIGN SYSTEM · V2.0

## Design read
Prime OS is a task-oriented strength-training product. The UI should feel like a focused operating system for training, not a generic fitness landing page.

## Skills applied
### Taste
- `DESIGN_VARIANCE`: 8
- `MOTION_INTENSITY`: 5
- `VISUAL_DENSITY`: 6
- deliberate type pairing: Barlow Condensed + DM Sans
- one functional accent: Prime Lime
- asymmetrical command-center layout
- cards used only for meaningful hierarchy

### Impeccable
- Operate mode for the product UI
- strong information hierarchy
- empty/fallback states
- responsive behavior for 1440/1200/900/650 widths
- focus-visible states and accessible labels
- edge-case handling for missing remote dataset and missing media
- data truth preserved: no fabricated performance history

### Emil Design Engineering
- motion reserved for page entry, press feedback, modal entry, timer/state changes
- no looping animation on ordinary controls
- tactile button feedback is immediate and subtle
- exercise preview uses media as content, not decoration
- charts render from actual stored data rather than fake trend lines

## Color tokens
- Background: `#0A0C0D`
- Surface: `#131719`
- Surface 2: `#171C1F`
- Ink: `#F2F5F3`
- Muted: `#8A9491`
- Prime Lime: `#B7FF4A`
- Cyan signal: `#6EE7FF`
- Warning: `#FFB454`
- Danger: `#FF6673`

## Muscle vocabulary
The interface uses the exercise dataset's body-part / target / muscle-group terminology. Workout coverage is computed from the user's current routine rather than invented values.
