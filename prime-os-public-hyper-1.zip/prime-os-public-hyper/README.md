# PRIME OS · Public Hyper Redesign V2.0

Propuesta y build local de una nueva experiencia para **Prime OS Público**, basada en el repositorio de `mrg722/prime-os-entrenamiento-General` y en la referencia visual entregada.

## Diseño aplicado
- Taste: dirección visual intencional, anti-generic UI, tipografía display + body diferenciadas, densidad controlada, un acento principal y composición asimétrica.
- Impeccable: app orientada a operar, jerarquía, estados, responsive, accesibilidad básica, edge cases, import/export, datos locales y pantallas de loading/fallback.
- Emil Design Engineering: motion breve para entrada/transición, feedback táctil, timer, overlays y microinteracciones solo donde aportan señal.

## Fuentes de ejercicios
Este build consume `exercises-dataset` desde su fuente pública en GitHub:
https://github.com/hasaneyldrm/exercises-dataset

El README del dataset declara 1.324 ejercicios, GIFs y thumbnails de 180×180, metadatos musculares/equipamiento e instrucciones en 10 idiomas.

**Licencia:** el repositorio declara MIT para código/estructura/datos de ejercicios, pero sus imágenes/GIFs son © Gym visual y están sujetos a términos separados. El build mantiene la atribución declarada y no trata esos medios como MIT.

## MuscleWiki
No se incorpora una clave inventada. El layout deja la biblioteca y el modelo de media preparados para una fuente API adicional; MuscleWiki requiere API key y sus planes con uso comercial están documentados por su propia API.

## Ejecución
Abre `index.html` con un navegador moderno. La biblioteca intenta cargar el dataset remoto y usa una colección pequeña de respaldo si falla la conexión.

## Auditoría local realizada
- Sintaxis JS verificada con Node.
- Estructura HTML/CSS inspeccionada.
- Estados de fallback implementados para dataset remoto.
- No se modifica el repositorio original por este artefacto.
