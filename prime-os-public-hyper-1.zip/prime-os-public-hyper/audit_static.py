from pathlib import Path
from html.parser import HTMLParser
import json, re, sys

ROOT = Path(__file__).resolve().parent
class Parser(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=set(); self.views=set(); self.panels=set()
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if 'id' in d: self.ids.add(d['id'])
        if d.get('data-view'): self.views.add(d['data-view'])
        if d.get('data-view-panel'): self.panels.add(d['data-view-panel'])

p=Parser(); p.feed((ROOT/'index.html').read_text(encoding='utf-8'))
js=(ROOT/'app.js').read_text(encoding='utf-8')
refs=set(re.findall(r"qs\(['\"]#([A-Za-z0-9_-]+)", js))
missing=sorted(refs-p.ids)
required=['index.html','styles.css','app.js','manifest.json','README.md','DESIGN.md','AUDIT.md','NOTICE.md','MEDIA-SOURCE.md','SOURCE-BASELINE.md','SKILLS-APPLIED.md']
missing_files=[x for x in required if not (ROOT/x).exists()]
print('HTML IDs:', len(p.ids))
print('JS query refs:', len(refs))
print('Missing JS refs:', missing)
print('Navigation entries:', len(p.views))
print('View panels:', len(p.panels))
print('Navigation without panel:', sorted(p.views-p.panels))
print('Panel without navigation:', sorted(p.panels-p.views))
print('Required files missing:', missing_files)
print('JS syntax: run `node --check app.js`')

ok = not missing and not missing_files and p.views == p.panels
if ok:
    print('AUDIT PASS')
else:
    print('AUDIT FAIL'); sys.exit(1)
