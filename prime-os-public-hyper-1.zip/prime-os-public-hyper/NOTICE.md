# Media attribution

Prime OS Public Hyper uses remote exercise media from:
https://github.com/hasaneyldrm/exercises-dataset

The dataset's own LICENSE and NOTICE.md state that the exercise media in `images/` and `videos/` is © Gym visual, distributed at 180×180 with the attribution:

© Gym visual — https://gymvisual.com/

Reuse of that media is governed by Gym visual's Terms & Conditions and is not granted by the MIT license covering the dataset's code/structure/instruction text.

This build keeps that attribution in exercise detail views and limits the displayed media box to 180×180.
