# Prime OS · Source baseline used for the redesign

## Prime OS public source
- Repository: https://github.com/mrg722/prime-os-entrenamiento-General
- Branch: `main`
- Verified commit: `15dd02a8e44b5e98bfeda8ee1ffa0d7de4cd9514`
- Verified files at baseline:
  - `README.md`
  - `app.js`
  - `index.html`
  - `manifest.json`
  - `styles.css`

The public source README identifies the product as Prime OS Público V1.4 and describes local persistence, routine planning/execution separation, progress tracking, import, and personalized contact.

## Exercise dataset source
- Repository: https://github.com/hasaneyldrm/exercises-dataset
- Branch: `main`
- Verified commit: `7455efae41b330c265e7cd4b78dfa848e7ce5ebd`
- Dataset structure verified from its README:
  - `data/exercises.json`
  - `data/exercises.schema.json`
  - `images/`
  - `videos/`
  - `LICENSE`
  - `NOTICE.md`

## Design reference
The redesign also uses the provided Prime OS visual references uploaded in this conversation. They were treated as visual direction, not as a source of factual product data.
