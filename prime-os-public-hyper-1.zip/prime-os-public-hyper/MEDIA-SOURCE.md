# Exercise media integration

Prime OS V2.0 reads exercise metadata from:
https://github.com/hasaneyldrm/exercises-dataset

Media URL pattern:
`https://raw.githubusercontent.com/hasaneyldrm/exercises-dataset/main/<gif_url>`

The source dataset states that each exercise has a 180×180 thumbnail and animation GIF, and that the media is © Gym visual with a separate reuse policy. For that reason this build references the media instead of copying the full media corpus into the ZIP, and the rendered media container remains 180×180.

Attribution retained in the app:
`© Gym visual — https://gymvisual.com/`
